export class BlockoutDate {
  public id?: string;
  public churchId?: string;
  public personId?: string;
  public startDate?: Date;
  public endDate?: Date;
}
