export class Automation {
  public id?: string;
  public churchId?: string;
  public title?: string;
  public recurs?: string;
  public active?: boolean;
}
