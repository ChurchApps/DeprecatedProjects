export class Assignment {
  public id?: string;
  public churchId?: string;
  public positionId?: string;
  public personId?: string;
  public status?: string;
  public notified?: Date;
}
