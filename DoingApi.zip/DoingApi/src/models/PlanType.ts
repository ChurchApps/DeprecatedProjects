export class PlanType {
  public id?: string;
  public churchId?: string;
  public ministryId?: string;
  public name?: string;
}