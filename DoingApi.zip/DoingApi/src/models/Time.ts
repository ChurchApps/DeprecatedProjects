export class Time {
  public id?: string;
  public churchId?: string;
  public planId?: string;
  public displayName?: string;
  public startTime?: Date;
  public endTime?: Date;
  public teams?: string;
}
