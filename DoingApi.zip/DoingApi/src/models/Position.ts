export class Position {
  public id?: string;
  public churchId?: string;
  public planId?: string;
  public categoryName?: string;
  public name?: string;
  public count?: number;
  public groupId?: string;
}
