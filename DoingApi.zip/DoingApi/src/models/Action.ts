export class Action {
  public id?: string;
  public churchId?: string;
  public automationId?: string;
  public actionType?: string;
  public actionData?: string;
}
