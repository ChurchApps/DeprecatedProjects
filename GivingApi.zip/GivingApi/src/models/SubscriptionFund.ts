export class SubscriptionFund {
  public id?: string;
  public churchId?: string;
  public subscriptionId?: string;
  public fundId?: string;
  public amount?: number;
}
