export class CheckoutDetails {
  public churchId: string = "";
  public amount: number = 0;
  public successUrl: string = "";
  public cancelUrl: string = "";
}
