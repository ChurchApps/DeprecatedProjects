import { DonationSummaryDonation } from "./DonationSummaryDonation";

export class DonationSummary {
  public week: number = 0;
  public donations?: DonationSummaryDonation[];
}
