export class Customer {
  public id?: string;
  public churchId?: string;
  public personId?: string;
}
