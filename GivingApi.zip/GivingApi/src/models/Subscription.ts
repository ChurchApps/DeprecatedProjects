export class Subscription {
  public id: string = "";
  public churchId?: string;
  public personId?: string;
  public customerId?: string;
}
