export class Fund {
  public id?: string;
  public churchId?: string;
  public name?: string;
  public taxDeductible?: boolean;
  public productId?: string;
  public amount?: number;
}
