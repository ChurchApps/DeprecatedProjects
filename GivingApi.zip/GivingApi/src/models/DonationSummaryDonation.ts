import { Fund } from "./Fund";

export class DonationSummaryDonation {
  public totalAmount: number = 0;
  public fund?: Fund;
}
