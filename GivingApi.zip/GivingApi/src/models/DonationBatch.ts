export class DonationBatch {
  public id?: string;
  public churchId?: string;
  public name?: string;
  public batchDate?: Date;

  public donationCount?: number;
  public totalAmount?: number;
}
