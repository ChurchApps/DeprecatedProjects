export class Gateway {
  public id?: string;
  public churchId?: string;
  public provider?: string;
  public publicKey?: string;
  public privateKey?: string;
  public webhookKey?: string;
  public productId?: string;
  public payFees?: boolean;
}
