const {
  execSync
} = require("child_process");
const fs = require("fs");
const path = require("path");

function checkFFmpeg() {
  try {
    execSync(
      "ffmpeg -version",
      {
        stdio:
          "ignore"
      }
    );
    console.log(
      "✅ FFmpeg is installed"
    );
    return true;
  } catch (error) {
    console.error(
      "❌ FFmpeg is not installed or not in PATH"
    );
    console.log(
      "\nPlease install FFmpeg:"
    );
    console.log(
      "Windows:"
    );
    console.log(
      "  1. Download from https://ffmpeg.org/download.html"
    );
    console.log(
      "  2. Add FFmpeg to your PATH"
    );
    console.log(
      "\nmacOS:"
    );
    console.log(
      "  brew install ffmpeg"
    );
    console.log(
      "\nLinux:"
    );
    console.log(
      "  sudo apt-get install ffmpeg"
    );
    return false;
  }
}

function checkNodeVersion() {
  const requiredVersion =
    "14.0.0";
  const currentVersion =
    process.version;

  if (
    currentVersion <
    requiredVersion
  ) {
    console.error(
      `❌ Node.js version ${requiredVersion} or higher is required`
    );
    console.log(
      `Current version: ${currentVersion}`
    );
    return false;
  }

  console.log(
    `✅ Node.js version ${currentVersion} is compatible`
  );
  return true;
}

function checkSampleData() {
  const sampleDir =
    path.join(
      process.cwd(),
      "sampleData"
    );
  if (
    !fs.existsSync(
      sampleDir
    )
  ) {
    console.log(
      "ℹ️  Creating sample data directory..."
    );
    fs.mkdirSync(
      sampleDir
    );
  }

  const scriptPath =
    path.join(
      sampleDir,
      "script.xml"
    );
  if (
    !fs.existsSync(
      scriptPath
    )
  ) {
    console.log(
      "ℹ️  Creating sample script.xml..."
    );
    const sampleScript = `<?xml version="1.0" encoding="UTF-8"?>
<tutorial>
  <speak>Welcome to the tutorial maker!</speak>
  <speak>This is a sample tutorial script.</speak>
</tutorial>`;
    fs.writeFileSync(
      scriptPath,
      sampleScript
    );
  }

  console.log(
    "✅ Sample data directory is ready"
  );
  return true;
}

// Run all checks
console.log(
  "🔍 Checking dependencies...\n"
);

const checks =
  [
    checkFFmpeg,
    checkNodeVersion,
    checkSampleData
  ];

const allPassed =
  checks.every(
    (
      check
    ) =>
      check()
  );

if (
  allPassed
) {
  console.log(
    "\n✨ All dependencies are properly installed!"
  );
  console.log(
    "\nTo get started:"
  );
  console.log(
    "1. Place your tutorial images in the sampleData directory"
  );
  console.log(
    "2. Edit script.xml with your tutorial content"
  );
  console.log(
    "3. Run: npm start"
  );
} else {
  console.log(
    "\n❌ Some dependencies are missing. Please fix the issues above and try again."
  );
  process.exit(
    1
  );
}
