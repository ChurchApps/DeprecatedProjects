# Tutorial Maker

A Node.js application that creates tutorial videos from instruction files and images.

## Installation

### Windows (Recommended)

1. Download the latest `TutorialMaker.zip` from the [Releases](https://github.com/ChurchApps/tutorial-maker/releases) page
2. Extract the ZIP file to any location
3. Double-click `TutorialMaker.bat` to start the application

Note: Make sure you have Node.js and FFmpeg installed on your system.

### Manual Installation

#### Prerequisites

- Node.js 14.0.0 or higher
- FFmpeg (required for video processing)

#### Steps

1. Clone this repository:

   ```bash
   git clone https://github.com/ChurchApps/tutorial-maker.git
   cd tutorial-maker
   ```

2. Install dependencies:

   ```bash
   npm install
   ```

3. Check your environment setup:

   ```bash
   npm run check-deps
   ```

   This will verify that all required dependencies are installed and create a sample data directory.

4. Place your tutorial images in the `sampleData` directory.

5. Edit `sampleData/script.xml` with your tutorial content. Example:

   ```xml
   <?xml version="1.0" encoding="UTF-8"?>
   <tutorial>
     <speak>Welcome to this tutorial!</speak>
     <video src="example.mp4" />
     <speak>This is the next step.</speak>
   </tutorial>
   ```

6. Run the application:
   ```bash
   npm start
   ```

The output video will be saved as `output.mp4` in the current directory.

## Script Format

The `script.xml` file supports the following elements:

- `<speak>`: Text to be converted to speech
- `<video>`: Include an existing video file
  - `src` attribute: Path to the video file

## Development

### Building the Package

To create a distributable package:

```bash
npm run build
```

This will create a `TutorialMaker.zip` file containing everything needed to run the application.

### Running Tests

Run tests:

```bash
npm test
```

Run tests in watch mode:

```bash
npm run test:watch
```

## Troubleshooting

### FFmpeg Not Found

If you see an error about FFmpeg not being found:

- **Windows**:

  1. Download FFmpeg from https://ffmpeg.org/download.html
  2. Add FFmpeg to your system PATH
  3. Restart your terminal/command prompt

- **macOS**:

  ```bash
  brew install ffmpeg
  ```

- **Linux**:
  ```bash
  sudo apt-get install ffmpeg
  ```

### Node.js Version

If you see a Node.js version error, install a newer version from https://nodejs.org/

### Installation Issues

If you encounter any issues during installation:

1. Make sure you have Node.js 14.0.0 or higher installed
2. Make sure FFmpeg is installed and in your PATH
3. Try running `npm run check-deps` to verify your environment

## License

MIT
