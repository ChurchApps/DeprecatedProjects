@echo off
echo Tutorial Maker
echo =============
echo.

REM Check for Node.js
where node >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo Error: Node.js is not installed or not in PATH
    echo Please install Node.js from https://nodejs.org/
    echo.
    pause
    exit /b 1
)

REM Check for FFmpeg
where ffmpeg >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo Error: FFmpeg is not installed or not in PATH
    echo Please install FFmpeg from https://ffmpeg.org/download.html
    echo.
    pause
    exit /b 1
)

REM Run the application without changing the current directory
set "SCRIPT_DIR=%~dp0"
node "%SCRIPT_DIR%bin\index.js"

echo.
pause