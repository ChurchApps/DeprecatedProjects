# Tutorial Maker

A Node.js application that creates tutorial videos from instruction files and images.

## Working with Claude Code

The easiest way to create tutorials is using Claude Code. Simply:

1. **Take screenshots** - Name them `1.png`, `2.png`, etc. and add red arrows/boxes to highlight clickable elements
2. **Put them in a folder** - e.g., `/path/to/ChurchAppsSupport/videos/lessons/your-tutorial/`
3. **Ask Claude** - Use prompts like:
   - "I have images in [folder] - look at them and create a script.xml"
   - "Check the image sizes before generating the video"
   - "Add this tutorial to the setup page with accordion steps"

Claude will:
- Read and analyze your screenshots
- Write the script.xml with appropriate narration
- Check image sizes (must be 1920x1080 to avoid black bars)
- Resize images if needed using: `for f in *.png; do magick "$f" -resize 1920x1080! "$f"; done`
- Run `tutorial-maker` to generate the video
- Update the setup page with playlist entry and accordion steps
- Commit and push to GitHub

### Accordion Steps Format

When adding a new tutorial to a setup page, Claude adds:

1. **Playlist entry:**
```html
<li><a href="../videos/lessons/your-tutorial/output.mp4" data-steps="your-steps">Your Tutorial Name</a></li>
```

2. **Accordion steps:**
```html
<div id="your-steps" class="video-steps">
<h3>Steps</h3>
<div class="step-accordion">
  <div class="step-header" onclick="toggleStep(this)"><span class="step-num">1.</span><span class="step-text">Description of step 1</span><span class="step-arrow">▼</span></div>
  <div class="step-content"><img src="../videos/lessons/your-tutorial/1.png" onclick="showModal(this.src)"></div>
  <!-- Repeat for each step -->
</div>
</div>
```

## Companion Tools

### macOS Screenshot Tool

If you're on macOS, check out [tools/macos-screenshot](tools/macos-screenshot/) for one-click Chrome screenshots at exactly 1920x1080. It handles fullscreen mode, hides the URL bar, and crops the notch area automatically.

## Installation

### Windows (Recommended)

[Watch the Setup Video](https://github.com/ChurchApps/TutorialMaker/raw/refs/heads/main/sampleData/setup/output.mp4)

Note: Make sure you have Node.js 20 installed on your system

### Manual Installation

#### Prerequisites

- Node.js 14.0.0 or higher
- FFmpeg (required for video processing)

#### Steps

1. Clone this repository:

   ```bash
   git clone https://github.com/ChurchApps/tutorial-maker.git
   cd tutorial-maker
   ```

2. Install dependencies:

   ```bash
   npm install
   ```

3. Check your environment setup:

   ```bash
   npm run check-deps
   ```

   This will verify that all required dependencies are installed and create a sample data directory.

4. Place your tutorial images in the `sampleData` directory.

5. Edit `sampleData/script.xml` with your tutorial content. Example:

   ```xml
   <?xml version="1.0" encoding="UTF-8"?>
   <tutorial>
     <speak>Welcome to this tutorial!</speak>
     <video src="example.mp4" />
     <speak>This is the next step.</speak>
   </tutorial>
   ```

6. Run the application:
   ```bash
   npm start
   ```

The output video will be saved as `output.mp4` in the current directory.

## Script Format

The `script.xml` file supports the following elements:

- `<speak>`: Text to be converted to speech
- `<video>`: Include an existing video file
  - `src` attribute: Path to the video file

## Development

### Building the Package

To create a distributable package:

```bash
npm run build
```

This will create a `TutorialMaker.zip` file containing everything needed to run the application.

### Running Tests

Run tests:

```bash
npm test
```

Run tests in watch mode:

```bash
npm run test:watch
```

## Troubleshooting

### FFmpeg Not Found

If you see an error about FFmpeg not being found:

- **Windows**:

  1. Download FFmpeg from https://ffmpeg.org/download.html
  2. Add FFmpeg to your system PATH
  3. Restart your terminal/command prompt

- **macOS**:

  ```bash
  brew install ffmpeg
  ```

- **Linux**:
  ```bash
  sudo apt-get install ffmpeg
  ```

### Node.js Version

If you see a Node.js version error, install a newer version from https://nodejs.org/

### Installation Issues

If you encounter any issues during installation:

1. Make sure you have Node.js 14.0.0 or higher installed
2. Make sure FFmpeg is installed and in your PATH
3. Try running `npm run check-deps` to verify your environment

## License

MIT
