#!/bin/bash

# One-click fullscreen screenshot of Chrome (no URL bar) - 1920x1080 output
# For use with TutorialMaker - https://github.com/ChurchApps/TutorialMaker

SCREENSHOT_DIR="/Users/$USER/Desktop/Screenshots"
TEMP_DIR="$SCREENSHOT_DIR/temp"
DEFAULT_SCREENSHOT_LOC="$HOME/Desktop"

# Save original screenshot location and set to temp folder
ORIGINAL_LOC=$(defaults read com.apple.screencapture location 2>/dev/null || echo "$HOME/Desktop")
defaults write com.apple.screencapture location "$TEMP_DIR"
killall SystemUIServer 2>/dev/null

# Restore screenshot location on exit (even if script fails)
cleanup() {
    defaults write com.apple.screencapture location "$DEFAULT_SCREENSHOT_LOC"
    killall SystemUIServer 2>/dev/null
}
trap cleanup EXIT

# Detect Homebrew path (Apple Silicon vs Intel)
if [ -f /opt/homebrew/bin/cliclick ]; then
    CLICLICK=/opt/homebrew/bin/cliclick
    MAGICK=/opt/homebrew/bin/magick
else
    CLICLICK=/usr/local/bin/cliclick
    MAGICK=/usr/local/bin/magick
fi

# Check dependencies
if [ ! -f "$CLICLICK" ]; then
    echo "Error: cliclick not found. Install with: brew install cliclick"
    exit 1
fi

if [ ! -f "$MAGICK" ]; then
    echo "Error: ImageMagick not found. Install with: brew install imagemagick"
    exit 1
fi

# Check if Chrome has a window open
WINDOW_COUNT=$(osascript -e 'tell application "Google Chrome" to return count of windows' 2>/dev/null)
if [ "$WINDOW_COUNT" = "0" ] || [ -z "$WINDOW_COUNT" ]; then
    osascript -e 'display dialog "Please open a Chrome window first." buttons {"OK"} default button "OK" with icon caution with title "Screenshot"'
    exit 1
fi

# Create folders if they don't exist
mkdir -p "$TEMP_DIR"

# Find the next available number
NUM=1
while [ -f "$SCREENSHOT_DIR/$NUM.png" ]; do
    NUM=$((NUM + 1))
done

# Reset Chrome window to normal size and activate
osascript -e '
tell application "Google Chrome"
    activate
    if (count of windows) > 0 then
        set bounds of front window to {100, 100, 1200, 800}
    end if
end tell'

sleep 0.5

# Enter fullscreen with Control+Cmd+F
"$CLICLICK" kd:ctrl,cmd t:f ku:ctrl,cmd

# Wait for fullscreen animation and any messages to disappear
sleep 5.5

# Capture full screen: Cmd+Shift+3
"$CLICLICK" kd:cmd,shift t:3 ku:cmd,shift
sleep 5

# Exit fullscreen
"$CLICLICK" kd:ctrl,cmd t:f ku:ctrl,cmd
sleep 0.5

# Detect if this Mac has a notch (MacBook Pro 14/16 2021+, MacBook Air 2022+)
# These models have a menu bar height of ~74-75px due to the notch
# Standard Macs have ~24px menu bar
has_notch() {
    # Get the main display's menu bar height via screen frame
    # Notch Macs report a larger safe area inset
    local model=$(sysctl -n hw.model 2>/dev/null)

    # Check for known notch models (MacBookPro18,x = 2021 14/16", MacBookPro17,x and later)
    # MacBookAir10,1 = M1 Air (no notch), MacBookAir11,1 = M2 Air (has notch)
    case "$model" in
        MacBookPro18,*|MacBookPro17,*|Mac14,*|Mac15,*|MacBookAir11,*)
            return 0  # Has notch
            ;;
    esac

    # Fallback: check if screen height suggests notch (notch displays have specific resolutions)
    # 14" = 3024x1964, 16" = 3456x2234 (both have ~75px notch area in menu bar)
    local screen_height=$(system_profiler SPDisplaysDataType 2>/dev/null | grep "Resolution" | head -1 | sed 's/.*x //' | awk '{print $1}')
    if [[ "$screen_height" == "1964" ]] || [[ "$screen_height" == "2234" ]]; then
        return 0  # Has notch
    fi

    return 1  # No notch
}

# Process all png files in temp folder
cd "$TEMP_DIR"
for f in *.png; do
    if [ -f "$f" ]; then
        if has_notch; then
            # MacBook with notch: crop 75 pixels from top, then resize to 1920x1080
            echo "Detected MacBook with notch - cropping menu bar area"
            "$MAGICK" "$f" -chop 0x75 -resize 1920x1080! "$f"
        else
            # Standard Mac/external monitor: just resize to 1920x1080
            echo "Standard display detected - resizing only"
            "$MAGICK" "$f" -resize 1920x1080! "$f"
        fi

        mv -- "$f" "$SCREENSHOT_DIR/$NUM.png"
        echo ""
        echo "Screenshot saved: $SCREENSHOT_DIR/$NUM.png"
        echo "Dimensions: 1920x1080"
        NUM=$((NUM + 1))
    fi
done
