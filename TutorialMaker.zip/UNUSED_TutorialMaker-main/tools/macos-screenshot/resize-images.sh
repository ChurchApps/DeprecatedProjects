#!/bin/bash

# Image Resizer - Resize all images in a folder to 1920x1080 (stretch mode)
# For use with TutorialMaker - https://github.com/ChurchApps/TutorialMaker

TARGET_WIDTH=1920
TARGET_HEIGHT=1080

folder="$1"

if [ -z "$folder" ] || [ ! -d "$folder" ]; then
    echo "Usage: ./resize-images.sh /path/to/folder"
    echo "Resizes all images in the folder to 1920x1080"
    exit 1
fi

# Count images
total=$(find "$folder" -maxdepth 1 -type f \( -iname '*.png' -o -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.gif' -o -iname '*.tiff' -o -iname '*.bmp' \) | wc -l | tr -d ' ')

if [ "$total" -eq 0 ]; then
    echo "No images found in the folder."
    exit 0
fi

echo "Resizing $total image(s) to ${TARGET_WIDTH}x${TARGET_HEIGHT}..."

# Process each image
find "$folder" -maxdepth 1 -type f \( -iname '*.png' -o -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.gif' -o -iname '*.tiff' -o -iname '*.bmp' \) -print0 | while IFS= read -r -d '' img; do
    # Stretch to exact 1920x1080 (sips -z takes HEIGHT then WIDTH)
    sips -z $TARGET_HEIGHT $TARGET_WIDTH "$img" >/dev/null 2>&1
    echo "  Resized: $(basename "$img")"
done

echo "Done! Successfully resized $total image(s) to ${TARGET_WIDTH}x${TARGET_HEIGHT}"
