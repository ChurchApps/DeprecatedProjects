# macOS Screenshot Tool

One-click Chrome screenshots at exactly 1920x1080 for TutorialMaker.

## What's Included

- **screenshot.sh** - Takes fullscreen Chrome screenshots (hides URL bar)
- **resize-images.sh** - Batch resize existing images to 1920x1080

## Installation

### 1. Install Dependencies

```bash
brew install cliclick imagemagick
```

### 2. Make Scripts Executable

```bash
chmod +x screenshot.sh resize-images.sh
```

### 3. Grant Screen Recording Permission

**CRITICAL:** Your terminal app needs permission to capture screenshots.

**Quick Open:** Run this command to jump directly to Screen Recording settings:
```bash
open "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture"
```

Then:
1. Click the **lock** icon (bottom left) and authenticate
2. Find your terminal app in the list (Terminal, iTerm2, etc.)
3. Toggle it **ON**
4. **Important:** Completely quit and restart your terminal app for the permission to take effect

### 4. Grant Accessibility Permissions

You must add BOTH `cliclick` AND your terminal app to Accessibility permissions:

**Quick Open:** Run this command to jump directly to Accessibility settings:
```bash
open "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility"
```

Then:
1. Click the **lock** icon (bottom left) and authenticate
2. Click **+** and add `cliclick`:
   - Apple Silicon: `/opt/homebrew/bin/cliclick`
   - Intel Mac: `/usr/local/bin/cliclick`
   - (Press **Cmd+Shift+G** in the file picker to enter the path)
3. Click **+** again and add **Terminal** (or iTerm, VS Code, etc.):
   - Go to `/Applications/Utilities/` and select **Terminal.app**
   - Or add whichever terminal app you use
4. Toggle BOTH to ON

**Important:** Both `cliclick` AND your terminal app must be enabled in Accessibility or the script will not work.

**Note:** If using the TutorialScreenshot.app, you may also need to add the app itself to Accessibility permissions.

### 5. Configure Chrome

1. Open Chrome > **View** menu
2. Make sure **"Always Show Toolbar in Full Screen"** is **UNCHECKED**

## Usage

### Taking Screenshots

1. Open Chrome and navigate to the page you want
2. Run the script:
   ```bash
   ./screenshot.sh
   ```
3. Wait ~12 seconds for the process
4. Screenshot saves to `~/Desktop/Screenshots/1.png` (numbered sequentially)

### Resizing Existing Images

```bash
./resize-images.sh /path/to/your/images
```

This resizes all images in the folder to exactly 1920x1080 (stretch mode).

## How screenshot.sh Works

1. Activates Chrome and enters fullscreen mode (hides URL bar)
2. Waits for fullscreen animation to complete
3. Takes a native macOS screenshot (Cmd+Shift+3)
4. **Auto-detects notch vs standard display:**
   - MacBook Pro 14"/16" (2021+) or MacBook Air M2+: Crops 75px from top to remove the notch/menu bar area
   - Desktop Macs, older MacBooks, or external monitors: Just resizes without cropping
5. Resizes to exactly 1920x1080
6. Saves with sequential numbering

## Creating a Dock-Ready Launcher (Recommended)

The most reliable way to create a one-click launcher is using a `.command` file:

### Create the Launcher

```bash
cat > ~/Desktop/TutorialScreenshot.command << 'EOF'
#!/bin/bash
cd /Users/terrybyrd/TutorialMaker/tools/macos-screenshot
./screenshot.sh
EOF
chmod +x ~/Desktop/TutorialScreenshot.command
```

**Note:** Update the path if your TutorialMaker is in a different location.

### Add to Dock

1. Drag `TutorialScreenshot.command` from your Desktop to your dock
2. It stays there permanently (survives restarts)
3. Click it anytime to take a screenshot

### Customize the Icon

1. Extract the Screenshot app icon:
   ```bash
   cp /System/Applications/Utilities/Screenshot.app/Contents/Resources/AppIcon.icns ~/Desktop/ScreenshotIcon.icns
   sips -s format png ~/Desktop/ScreenshotIcon.icns --out ~/Desktop/ScreenshotIcon.png
   ```

2. Apply the icon:
   - Open `ScreenshotIcon.png` in Preview
   - Press **Cmd+A** (select all), then **Cmd+C** (copy)
   - Right-click `TutorialScreenshot.command` > **Get Info**
   - Click the small icon in the top-left corner
   - Press **Cmd+V** (paste)

3. Delete the temp icon files:
   ```bash
   rm ~/Desktop/ScreenshotIcon.{icns,png}
   ```

### Why .command Instead of .app?

- **More reliable**: Doesn't get stuck running in the background
- **Simpler permissions**: Only needs the permissions you've already granted
- **Easier to update**: Just edit the text file
- **Works every time**: No issues with app state or caching

## Alternative: AppleScript App (Not Recommended)

You can create a `.app` with Script Editor, but AppleScript apps can:
- Get stuck running in the background
- Require additional Automation permissions
- Be less reliable when clicked multiple times

If you still want to try it:

1. Open **Script Editor** (in Applications > Utilities)
2. Paste this code:
   ```applescript
   do shell script "'/path/to/TutorialMaker/tools/macos-screenshot/screenshot.sh'"
   ```
3. File > Export > Format: **Application**
4. Save as `Screenshot.app`

**Troubleshooting .app issues:**
- If it stops working, kill stuck processes: `killall -9 applet`
- Add the app to both Screen Recording and Accessibility permissions
- Add it to Automation permissions to control Terminal

## Troubleshooting

### No screenshots are created (temp directory empty)

- **Most common issue:** Your terminal app doesn't have Screen Recording permission
- Run: `open "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture"`
- Enable your terminal app (Terminal, iTerm2, etc.)
- **Must completely quit and restart your terminal** for the permission to take effect

### Screenshots are black or wrong size

- Make sure Chrome's "Always Show Toolbar in Full Screen" is UNCHECKED
- Try increasing the sleep values in screenshot.sh if your Mac is slow

### "cliclick" permission denied

- Add BOTH `cliclick` AND Terminal to Accessibility permissions in System Settings (see step 4 above)
- Path should be `/opt/homebrew/bin/cliclick` (Apple Silicon) or `/usr/local/bin/cliclick` (Intel)

### AppleScript .app stops working after first click

- The app may be stuck running in the background
- Kill it with: `killall -9 applet`
- **Solution:** Use the `.command` file approach instead (see "Creating a Dock-Ready Launcher" above)

### Wrong Homebrew path

The script auto-detects Apple Silicon (`/opt/homebrew/bin/`) vs Intel (`/usr/local/bin/`). If it fails, check your paths:

```bash
which cliclick
which magick
```
