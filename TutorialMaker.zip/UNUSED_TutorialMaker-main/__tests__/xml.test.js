const fs = require("fs");
const {
  DOMParser
} = require("xmldom");
const xpath = require("xpath");

describe("XML Parsing", () => {
  const sampleXml = `
    <tutorial>
      <speak>Hello, this is a test</speak>
      <video src="test.mp4" />
      <speak>Another test message</speak>
    </tutorial>
  `;

  test("should parse XML correctly", () => {
    const dom =
      new DOMParser().parseFromString(
        sampleXml,
        "text/xml"
      );
    const nodes =
      xpath.select(
        "/tutorial/*",
        dom
      );

    expect(
      nodes.length
    ).toBe(
      3
    );
    expect(
      nodes[0]
        .nodeName
    ).toBe(
      "speak"
    );
    expect(
      nodes[1]
        .nodeName
    ).toBe(
      "video"
    );
    expect(
      nodes[2]
        .nodeName
    ).toBe(
      "speak"
    );
  });

  test("should extract video source correctly", () => {
    const dom =
      new DOMParser().parseFromString(
        sampleXml,
        "text/xml"
      );
    const nodes =
      xpath.select(
        "/tutorial/*",
        dom
      );
    const videoNode =
      nodes[1];

    expect(
      videoNode.getAttribute(
        "src"
      )
    ).toBe(
      "test.mp4"
    );
  });
});
