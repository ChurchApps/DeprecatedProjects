const fs = require("fs");

// Mock the fetch function
global.fetch =
  jest.fn();

describe("Audio Handling", () => {
  beforeEach(
    () => {
      // Clear all mocks before each test
      jest.clearAllMocks();
    }
  );

  test("should handle audio data loading", async () => {
    const mockResponse =
      {
        json: jest
          .fn()
          .mockResolvedValue(
            {
              buffer:
                "base64EncodedAudioData",
              meta: [
                {
                  value:
                    "image1",
                  time: 0
                },
                {
                  value:
                    "image2",
                  time: 5000
                }
              ]
            }
          )
      };

    global.fetch.mockResolvedValue(
      mockResponse
    );

    const loadData =
      async (
        ssml
      ) => {
        const body =
          {
            ssml: ssml
          };
        const options =
          {
            method:
              "POST",
            headers:
              {
                "Content-Type":
                  "application/json"
              },
            body: JSON.stringify(
              body
            )
          };
        const response =
          await fetch(
            "https://api.staging.churchapps.org/content/support/createAudio",
            options
          );
        return response.json();
      };

    const result =
      await loadData(
        "<speak>Test audio</speak>"
      );

    expect(
      fetch
    ).toHaveBeenCalledWith(
      "https://api.staging.churchapps.org/content/support/createAudio",
      expect.objectContaining(
        {
          method:
            "POST",
          headers:
            {
              "Content-Type":
                "application/json"
            },
          body: JSON.stringify(
            {
              ssml: "<speak>Test audio</speak>"
            }
          )
        }
      )
    );

    expect(
      result
    ).toEqual(
      {
        buffer:
          "base64EncodedAudioData",
        meta: [
          {
            value:
              "image1",
            time: 0
          },
          {
            value:
              "image2",
            time: 5000
          }
        ]
      }
    );
  });

  test("should parse MP3 data correctly", () => {
    const mockWriteFileSync =
      jest.spyOn(
        fs,
        "writeFileSync"
      );
    const base64Data =
      "SGVsbG8gV29ybGQ="; // "Hello World" in base64
    const filePath =
      "test.mp3";

    const parseMp3 =
      (
        base64,
        filePath
      ) => {
        const buffer =
          Buffer.from(
            base64,
            "base64"
          );
        fs.writeFileSync(
          filePath,
          buffer
        );
      };

    parseMp3(
      base64Data,
      filePath
    );

    expect(
      mockWriteFileSync
    ).toHaveBeenCalledWith(
      filePath,
      expect.any(
        Buffer
      )
    );
  });
});
