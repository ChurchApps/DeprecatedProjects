const fs = require("fs");
const {
  FFCreator,
  FFScene,
  FFImage
} = require("ffcreator");

// Mock the FFCreator and related classes
jest.mock(
  "ffcreator",
  () => {
    return {
      FFCreator:
        jest
          .fn()
          .mockImplementation(
            () => ({
              addChild:
                jest.fn(),
              output:
                jest.fn(),
              start:
                jest.fn(),
              on: jest.fn(),
              closeLog:
                jest.fn()
            })
          ),
      FFScene:
        jest
          .fn()
          .mockImplementation(
            () => ({
              setBgColor:
                jest.fn(),
              setDuration:
                jest.fn(),
              addChild:
                jest.fn()
            })
          ),
      FFImage:
        jest
          .fn()
          .mockImplementation(
            () => ({})
          )
    };
  }
);

describe("Video Creation", () => {
  beforeEach(
    () => {
      // Clear all mocks before each test
      jest.clearAllMocks();
    }
  );

  test("should create scene with correct parameters", () => {
    const creator =
      new FFCreator();
    const imagePath =
      "test.png";
    const duration = 5000;

    // Mock the createScene function
    const createScene =
      (
        creator,
        imagePath,
        duration
      ) => {
        const scene =
          new FFScene(
            {
              x: 0,
              y: 0
            }
          );
        scene.setBgColor(
          "#000000"
        );
        scene.setDuration(
          duration /
            1000
        );
        creator.addChild(
          scene
        );
        const image =
          new FFImage(
            {
              path: imagePath,
              width: 1920,
              height: 1080,
              x:
                1920 /
                2,
              y:
                1080 /
                2
            }
          );
        scene.addChild(
          image
        );
      };

    createScene(
      creator,
      imagePath,
      duration
    );

    expect(
      FFScene
    ).toHaveBeenCalledWith(
      {
        x: 0,
        y: 0
      }
    );
    expect(
      FFImage
    ).toHaveBeenCalledWith(
      {
        path: imagePath,
        width: 1920,
        height: 1080,
        x:
          1920 /
          2,
        y:
          1080 /
          2
      }
    );
  });

  test("should handle video creation process", async () => {
    const creator =
      new FFCreator();
    let completeCallback;
    let errorCallback;
    let progressCallback;

    // Mock the on method to capture callbacks
    creator.on =
      jest.fn(
        (
          event,
          callback
        ) => {
          if (
            event ===
            "complete"
          )
            completeCallback =
              callback;
          if (
            event ===
            "error"
          )
            errorCallback =
              callback;
          if (
            event ===
            "progress"
          )
            progressCallback =
              callback;
        }
      );

    // Mock the createVideo function
    const createVideo =
      async (
        audioPath,
        screenshots,
        fileName
      ) => {
        return new Promise(
          (
            resolve,
            reject
          ) => {
            creator.on(
              "complete",
              resolve
            );
            creator.on(
              "error",
              reject
            );
            creator.on(
              "progress",
              () => {}
            );
          }
        );
      };

    const screenshots =
      [
        {
          path: "test1.png",
          duration: 5000
        },
        {
          path: "test2.png",
          duration: 3000
        }
      ];

    // Start the video creation process
    const videoPromise =
      createVideo(
        "test.mp3",
        screenshots,
        "output.mp4"
      );

    // Simulate progress updates
    if (
      progressCallback
    ) {
      progressCallback(
        {
          percent: 0.25
        }
      );
      progressCallback(
        {
          percent: 0.5
        }
      );
      progressCallback(
        {
          percent: 0.75
        }
      );
    }

    // Simulate completion
    if (
      completeCallback
    ) {
      completeCallback();
    }

    // Wait for the promise to resolve
    await expect(
      videoPromise
    ).resolves.toBeUndefined();

    // Verify event handlers were set up correctly
    expect(
      creator.on
    ).toHaveBeenCalledWith(
      "complete",
      expect.any(
        Function
      )
    );
    expect(
      creator.on
    ).toHaveBeenCalledWith(
      "error",
      expect.any(
        Function
      )
    );
    expect(
      creator.on
    ).toHaveBeenCalledWith(
      "progress",
      expect.any(
        Function
      )
    );
  }, 10000); // Increased timeout to 10 seconds
});
