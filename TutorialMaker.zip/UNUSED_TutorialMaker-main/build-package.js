const {
  execSync
} = require("child_process");
const fs = require("fs");
const path = require("path");
const archiver = require("archiver");

// Ensure we're in the right directory
process.chdir(
  __dirname
);

console.log(
  "🔨 Building Tutorial Maker package..."
);

// Step 1: Install dependencies
console.log(
  "\n📦 Installing dependencies..."
);
execSync(
  "npm install",
  {
    stdio:
      "inherit"
  }
);

// Step 2: Run tests
console.log(
  "\n🧪 Running tests..."
);
execSync(
  "npm test",
  {
    stdio:
      "inherit"
  }
);

// Step 3: Create package directory
const packageDir =
  path.join(
    __dirname,
    "package"
  );
if (
  fs.existsSync(
    packageDir
  )
) {
  fs.rmSync(
    packageDir,
    {
      recursive: true
    }
  );
}
fs.mkdirSync(
  packageDir
);

// Step 4: Copy necessary files
console.log(
  "\n📋 Copying files..."
);
const filesToCopy =
  [
    "bin",
    "node_modules",
    "package.json",
    "package-lock.json",
    "LICENSE",
    "README.md"
  ];

filesToCopy.forEach(
  (
    file
  ) => {
    const source =
      path.join(
        __dirname,
        file
      );
    const dest =
      path.join(
        packageDir,
        file
      );
    if (
      fs.existsSync(
        source
      )
    ) {
      if (
        fs
          .lstatSync(
            source
          )
          .isDirectory()
      ) {
        fs.cpSync(
          source,
          dest,
          {
            recursive: true
          }
        );
      } else {
        fs.copyFileSync(
          source,
          dest
        );
      }
    }
  }
);

// Step 5: Create sample data directory
const sampleDataDir =
  path.join(
    packageDir,
    "sampleData"
  );
fs.mkdirSync(
  sampleDataDir,
  {
    recursive: true
  }
);

// Create sample script.xml
const sampleScript = `<?xml version="1.0" encoding="UTF-8"?>
<tutorial>
  <speak>Welcome to the tutorial maker!</speak>
  <speak>This is a sample tutorial script.</speak>
</tutorial>`;
fs.writeFileSync(
  path.join(
    sampleDataDir,
    "script.xml"
  ),
  sampleScript
);

// Step 6: Create launcher batch file
const launcherContent = `@echo off
echo Tutorial Maker
echo =============
echo.

REM Check for Node.js
where node >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo Error: Node.js is not installed or not in PATH
    echo Please install Node.js from https://nodejs.org/
    echo.
    pause
    exit /b 1
)

REM Check for FFmpeg
where ffmpeg >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo Error: FFmpeg is not installed or not in PATH
    echo Please install FFmpeg from https://ffmpeg.org/download.html
    echo.
    pause
    exit /b 1
)

REM Run the application without changing the current directory
set "SCRIPT_DIR=%~dp0"
node "%SCRIPT_DIR%bin\\index.js"

echo.
pause`;
fs.writeFileSync(
  path.join(
    packageDir,
    "TutorialMaker.bat"
  ),
  launcherContent
);

// Step 7: Create ZIP file
console.log(
  "\n📦 Creating package..."
);
const output =
  fs.createWriteStream(
    "TutorialMaker.zip"
  );
const archive =
  archiver(
    "zip",
    {
      zlib: {
        level: 9
      }
    }
  );

output.on(
  "close",
  () => {
    console.log(
      "\n✨ Package created successfully!"
    );
    console.log(
      "\nTo use Tutorial Maker:"
    );
    console.log(
      "1. Extract TutorialMaker.zip"
    );
    console.log(
      "2. Double-click TutorialMaker.bat"
    );
    console.log(
      "\nNote: Make sure Node.js and FFmpeg are installed and in your PATH"
    );
  }
);

archive.on(
  "error",
  (
    err
  ) => {
    throw err;
  }
);

archive.pipe(
  output
);
archive.directory(
  packageDir,
  false
);
archive.finalize();
