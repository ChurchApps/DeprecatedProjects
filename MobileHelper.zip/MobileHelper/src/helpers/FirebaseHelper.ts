export class FirebaseHelper {
  static async addAnalyticsEvent(eventName: string, dataBody: any) {
    // No-op implementation - Firebase Analytics removed
  }

  static async addOpenScreenEvent(screenName: string) {
    // No-op implementation - Firebase Analytics removed
  }
}