export class FcmMessage {
  public action: string;
  public data: any;
}
