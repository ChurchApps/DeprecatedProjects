export class Connection {
  public id?: string;
  public churchId?: string;
  public conversationId?: string;
  public personId?: string;
  public displayName?: string;
  public timeJoined?: Date;
  public socketId?: string;
  public ipAddress?: string;
}
