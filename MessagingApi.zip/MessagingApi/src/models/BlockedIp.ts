export class BlockedIp {
  public id?: string;
  public churchId?: string;
  public conversationId?: string;
  public serviceId?: string;
  public ipAddress?: string;
}
