export class NotificationPreference {
  public id?: string;
  public churchId?: string;
  public personId?: string;
  public allowPush?: boolean;
  public emailFrequency?: string;
}
