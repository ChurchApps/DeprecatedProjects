export class DeviceContent {
  public id?: string;
  public churchId?: string;
  public deviceId?: string;
  public contentType?: string;
  public contentId?: string;
}
