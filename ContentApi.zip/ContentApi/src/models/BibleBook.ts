export class BibleBook {
  public id?: string;
  public translationKey?: string;
  public keyName?: string;
  public abbreviation?: string;
  public name?: string;
  public sort?: number;
}
