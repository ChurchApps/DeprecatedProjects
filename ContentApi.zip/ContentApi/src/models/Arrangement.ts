export class Arrangement {
  id?: string;
  churchId?: string;
  songId?: string;
  songDetailId?: string;
  name?: string;
  lyrics?: string;
  freeShowId?: string;
}
