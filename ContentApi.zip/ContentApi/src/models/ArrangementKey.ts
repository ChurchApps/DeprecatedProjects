export class ArrangementKey {
  id?: string;
  churchId?: string;
  arrangementId?: string;
  keySignature?: string;
  shortDescription?: string;
}
