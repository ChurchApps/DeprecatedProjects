export class BibleLookup {
  public id?: string;
  public translationKey?: string;
  public lookupTime?: Date;
  public ipAddress?: string;
  public startVerseKey?: string;
  public endVerseKey?: string;
}
