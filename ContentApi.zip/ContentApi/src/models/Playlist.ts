export class Playlist {
  id?: string;
  churchId: string;
  title: string;
  description: string;
  publishDate: Date;
  thumbnail: string;
}
