export class BibleChapter {
  public id?: string;
  public translationKey?: string;
  public bookKey?: string;
  public keyName?: string;
  public number?: number;
}
