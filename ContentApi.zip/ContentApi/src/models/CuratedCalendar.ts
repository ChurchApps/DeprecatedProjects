export class CuratedCalendar {
  public id?: string;
  public churchId?: string;
  public name?: string;
}
