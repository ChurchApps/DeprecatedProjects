export class Song {
  id?: string;
  churchId?: string;
  name?: string;
  dateAdded?: Date;
}
