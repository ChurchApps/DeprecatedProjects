export class BibleVerse {
  public id?: string;
  public translationKey?: string;
  public chapterKey?: string;
  public keyName?: number;
  public number?: number;
}
