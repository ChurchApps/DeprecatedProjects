export class Setting {
  public id?: string;
  public churchId?: string;
  public userId?: string;
  public keyName?: string;
  public value?: string;
  public public?: string;
}
