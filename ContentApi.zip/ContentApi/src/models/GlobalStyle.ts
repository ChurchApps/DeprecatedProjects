export class GlobalStyle {
  id?: string;
  churchId?: string;
  fonts?: string;
  palette?: string;
  customCss?: string;
  customJS?: string;
}
