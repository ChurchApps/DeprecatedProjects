export class EventException {
  id?: string;
  churchId?: string;
  eventId?: string;
  exceptionDate?: Date;
}
