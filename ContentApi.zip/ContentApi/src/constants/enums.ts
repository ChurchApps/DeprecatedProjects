export enum RoleContentType {
  ADMIN = "Admin"
}

export enum RoleAction {
  EDIT_SETTINGS = "Edit Settings"
}
