export enum RoleContentType {
  ADMIN = "Admin",
  PEOPLE = "People",
  GROUP_MEMBERS = "Group Members"
}

export enum RoleAction {
  EDIT_SETTINGS = "Edit Settings",
  EDIT = "Edit"
}
