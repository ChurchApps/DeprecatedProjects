export class Role {
  public id?: string;
  public churchId?: string;
  public name?: string;
}
