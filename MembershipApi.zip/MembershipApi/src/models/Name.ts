export class Name {
  public first?: string;
  public middle?: string;
  public last?: string;
  public nick?: string;
  public prefix?: string;
  public suffix?: string;
  public display?: string;
}
