export class UserChurch {
  public id?: string;
  public userId?: string;
  public churchId?: string;
  public personId?: string;
  public lastAccessed?: Date;
}
