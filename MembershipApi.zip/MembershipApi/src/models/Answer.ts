export class Answer {
  public id?: string;
  public churchId?: string;
  public formSubmissionId?: string;
  public questionId?: string;
  public value?: string;
}
