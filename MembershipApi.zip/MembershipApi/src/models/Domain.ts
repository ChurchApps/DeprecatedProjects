export class Domain {
  public id?: string;
  public churchId?: string;
  public domainName?: string;
}
