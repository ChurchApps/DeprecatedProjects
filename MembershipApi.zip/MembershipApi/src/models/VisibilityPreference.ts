export class VisibilityPreference {
  public id?: string;
  public churchId?: string;
  public personId?: string;
  public address?: string;
  public phoneNumber?: string;
  public email?: string;
}
