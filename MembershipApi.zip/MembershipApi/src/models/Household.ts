export class Household {
  public id?: string;
  public churchId?: string;
  public name?: string;
}
