export class MemberPermission {
  public id?: string;
  public churchId?: string;
  public memberId?: string;
  public contentType?: string;
  public contentId?: string;
  public action?: string;
  public personName?: string;
  public formName?: string;
  public emailNotification?: boolean;
}
