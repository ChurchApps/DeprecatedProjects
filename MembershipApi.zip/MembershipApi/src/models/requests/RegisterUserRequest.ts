export type RegisterUserRequest = {
  firstName: string;
  lastName: string;
  email: string;
  appName: string;
  appUrl: string;
  churchId: string;
};
