export type NewPasswordRequest = {
  authGuid: string;
  newPassword: string;
};
