export type ResetPasswordRequest = {
  userEmail: string;
  appName?: string;
  appUrl?: string;
};
