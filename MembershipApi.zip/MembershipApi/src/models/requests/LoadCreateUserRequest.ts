export type LoadCreateUserRequest = {
  firstName: string;
  lastName: string;
  userEmail: string;
  userId: string;
};
