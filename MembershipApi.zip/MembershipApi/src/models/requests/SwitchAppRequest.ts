export type SwitchAppRequest = {
  appName: string;
  churchId: number;
};
