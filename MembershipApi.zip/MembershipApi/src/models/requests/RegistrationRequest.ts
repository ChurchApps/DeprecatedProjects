export type RegistrationRequest = {
  email: string;
  firstName: string;
  lastName: string;
  churchName: string;
  subDomain: string;
  appName: string;
  appUrl: string;
};
