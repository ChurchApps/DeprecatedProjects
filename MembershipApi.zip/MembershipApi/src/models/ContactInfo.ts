export class ContactInfo {
  public homePhone?: string;
  public mobilePhone?: string;
  public workPhone?: string;
  public email?: string;
  public address1?: string;
  public address2?: string;
  public city?: string;
  public state?: string;
  public zip?: string;
}
