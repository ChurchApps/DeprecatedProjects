export class AccessLog {
  public id?: string;
  public userId?: string;
  public churchId?: string;
  public appName?: string;
  public loginTime?: Date;
}
