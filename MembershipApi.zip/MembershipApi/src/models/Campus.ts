export class Campus {
  public id: string;
  public name: string;
}
