import { Permission } from "./Permission";

export class PermissionGroup {
  public requireOne: Permission[];
}
