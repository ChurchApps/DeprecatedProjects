import { Column } from ".";

export class Output {
  public outputType?: string;
  public columns?: Column[];
}
