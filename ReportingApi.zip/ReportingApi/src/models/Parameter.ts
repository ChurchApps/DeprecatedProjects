export class Parameter {
  public keyName?: string;
  public source?: string;
  public sourceKey?: string;
  public value?: any | any[];
}
