export class Column {
  public header?: string;
  public value?: string;
  public formatter?: string;
}
