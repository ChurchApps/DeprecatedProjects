export class Permission {
  public api?: string;
  public contentType?: string;
  public action?: string;
}
