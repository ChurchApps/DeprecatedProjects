export class JoinCondition {
  public parent?: string;
  public child?: string;
}
