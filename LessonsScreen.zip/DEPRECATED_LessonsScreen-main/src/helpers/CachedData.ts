import AsyncStorage from "@react-native-async-storage/async-storage";
import { ChurchInterface, ClassroomInterface, LessonPlaylistFileInterface, PlanInterface, FeedVenueInterface } from "../interfaces";
import RNFS from "react-native-fs";
import * as Sentry from "@sentry/react-native";

export class CachedData {
  static church: ChurchInterface;
  static room: ClassroomInterface;
  static messageFiles: LessonPlaylistFileInterface[];

  // Plan pairing data
  static planTypeId: string | null = null;
  static pairedChurchId: string | null = null;
  static currentPlan: PlanInterface | null = null;
  static planVenue: FeedVenueInterface | null = null;

  static totalCachableItems: number = 0;
  static cachedItems: number = 0;
  static cachePath = RNFS.CachesDirectoryPath;

  static navExpanded = false;
  static currentScreen = "";
  static resolution: "720" | "1080" = "720";

  // Track active downloads for cleanup
  private static activeDownloads: Map<string, { jobId: number }> = new Map();

  static async getAsyncStorage(key: string) {
    try {
      const json = await AsyncStorage.getItem(key);
      if (json) return JSON.parse(json);
      return null;
    } catch (error) {
      console.error(`Failed to get AsyncStorage key "${key}":`, error);
      Sentry.addBreadcrumb({
        category: "storage",
        message: `Failed to get AsyncStorage key: ${key}`,
        level: "error",
      });
      return null;
    }
  }

  static async setAsyncStorage(key: string, obj: any) {
    try {
      await AsyncStorage.setItem(key, JSON.stringify(obj));
    } catch (error) {
      console.error(`Failed to set AsyncStorage key "${key}":`, error);
      Sentry.addBreadcrumb({
        category: "storage",
        message: `Failed to set AsyncStorage key: ${key}`,
        level: "error",
      });
    }
  }

  static async prefetch(files: LessonPlaylistFileInterface[], changeCallback: (cached: number, total: number) => void) {
    this.cachedItems = 0;
    let i = 0;
    this.totalCachableItems = files.length;
    changeCallback(this.cachedItems, this.totalCachableItems);

    for (const f of files) {
      try {
        // Skip files with invalid URLs
        if (!f.url || f.url.trim() === "") {
          console.log("Skipping file with empty URL");
          i++;
          this.cachedItems = i;
          changeCallback(this.cachedItems, this.totalCachableItems);
          continue;
        }
        await this.load(f);
      } catch (e) {
        const errorMessage = e instanceof Error ? e.message : String(e);
        console.log("Download Failed: " + errorMessage);

        // Only log non-abort errors to Sentry (aborts are expected during navigation)
        if (!errorMessage.includes("abort") && !errorMessage.includes("cancelled")) {
          Sentry.addBreadcrumb({
            category: "download",
            message: `Download failed for ${f.url}: ${errorMessage}`,
            level: "warning",
          });
        }
      }
      i++;
      this.cachedItems = i;
      changeCallback(this.cachedItems, this.totalCachableItems);
    }
  }

  static getFilePath(url: string) {
    if (!url) return "";
    const parts = url.split("?")[0].split("/");
    parts.splice(0, 3);
    const fullPath = RNFS.CachesDirectoryPath + "/" + parts.join("/");
    return fullPath;
  }

  static async load(file: LessonPlaylistFileInterface) {
    if (!file.url) return;
    let fullPath = this.getFilePath(file.url);
    fullPath = decodeURIComponent(fullPath);
    if (!await RNFS.exists(fullPath)) await this.download(file, fullPath);
  }

  private static async download(file: LessonPlaylistFileInterface, diskPath: string) {
    if (!file.url) {
      throw new Error("Cannot download file with empty URL");
    }

    const idx = diskPath.lastIndexOf("/");
    const folder = diskPath.substring(0, idx);

    try {
      if (!await RNFS.exists(folder)) await RNFS.mkdir(folder);
    } catch (mkdirError) {
      // Directory might already exist or be created by another download
      console.log("mkdir warning:", mkdirError);
    }

    const downloadResponse = RNFS.downloadFile({ fromUrl: file.url, toFile: diskPath });

    // Track the download so it can be cancelled if needed
    this.activeDownloads.set(file.url, { jobId: downloadResponse.jobId });

    try {
      const result = await downloadResponse.promise;
      // Check if download was successful
      if (result.statusCode !== 200) {
        throw new Error(`Download failed with status ${result.statusCode}`);
      }
    } finally {
      // Clean up tracking
      this.activeDownloads.delete(file.url);
    }
  }

  // Cancel all active downloads (useful when navigating away)
  static cancelAllDownloads() {
    this.activeDownloads.forEach((download, url) => {
      try {
        RNFS.stopDownload(download.jobId);
        console.log("Cancelled download:", url);
      } catch (e) {
        // Ignore errors when cancelling
      }
    });
    this.activeDownloads.clear();
  }

}
