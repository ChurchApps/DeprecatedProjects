import { Campus } from "./";
export class Service {
  public id?: string;
  public churchId?: string;
  public campusId?: string;
  public name?: string;

  public campus?: Campus;
}
