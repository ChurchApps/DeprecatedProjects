import { ServiceTime } from "./";

export class GroupServiceTime {
  public id?: string;
  public churchId?: string;
  public groupId?: string;
  public serviceTimeId?: string;

  public serviceTime?: ServiceTime;
}
