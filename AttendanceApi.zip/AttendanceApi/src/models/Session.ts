export class Session {
  public id?: string;
  public churchId?: string;
  public groupId?: string;
  public serviceTimeId?: string;
  public sessionDate?: Date;

  public displayName?: string;
}
