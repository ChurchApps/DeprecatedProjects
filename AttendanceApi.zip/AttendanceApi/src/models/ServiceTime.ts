// import { Group } from "./";

export class ServiceTime {
  public id?: string;
  public churchId?: string;
  public serviceId?: string;
  public name?: string;

  public longName?: string;
  // public groups?: Group[];
}
