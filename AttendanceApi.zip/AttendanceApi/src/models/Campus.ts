export class Campus {
  public id?: string;
  public churchId?: string;
  public name?: string;
  public address1?: string;
  public address2?: string;
  public city?: string;
  public state?: string;
  public zip?: string;

  public importKey?: string;
}
